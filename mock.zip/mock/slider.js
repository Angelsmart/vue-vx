module.exports = ["https://img.alicdn.com/simba/img/TB1Rdz6iSzqK1RjSZFHSuv3CpXa.jpg_q50.jpg",
"https://gw.alicdn.com/imgextra/i3/42/O1CN011CBH6Mf8X4UYIQm_!!42-0-lubanu.jpg",
"https://img.alicdn.com/simba/img/TB159lRXNTpK1RjSZFMSuvG_VXa.jpg_q50.jpg"
]
